<?php

return [
	'default' => [
		'bookmarks/' => __DIR__ . '/graphics',
	],
];
