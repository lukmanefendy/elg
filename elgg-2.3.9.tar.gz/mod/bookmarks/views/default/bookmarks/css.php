.elgg-icon-bookmark {
	background: transparent url(<?= elgg_get_simplecache_url('bookmarks/bookmark.gif'); ?>);
}