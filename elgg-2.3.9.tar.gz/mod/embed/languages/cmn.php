<?php
return array(
	'embed:embed' => '內嵌',
	'embed:media' => '內嵌內容',
	'embed:instructions' => '在任何檔案上按一下以將它內嵌到您的內容。',
	'embed:upload' => '上傳媒體',
	'embed:upload_type' => '上傳類型：',

	// messages
	'embed:no_upload_content' => '沒有上傳內容！',
	'embed:no_section_content' => '找不到任何項目。',

	'embed:no_sections' => '找不到任何支援的內嵌外掛程式。請向站臺管理者要求啟用具內嵌支援的外掛程式。',
);