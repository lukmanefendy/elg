<?php
return array(
	'embed:embed' => 'Incorporar',
	'embed:media' => 'Incorporar mídia',
	'embed:instructions' => 'Clique em qualquer arquivo para incorporá-lo ao conteúdo.',
	'embed:upload' => 'Enviar mídia',
	'embed:upload_type' => 'Tipo enviado:',

	// messages
	'embed:no_upload_content' => 'Nenhum conteúdo enviado!',
	'embed:no_section_content' => 'Nenhum item encontrado.',

	'embed:no_sections' => 'Nenhum plugin de suporte a incorporação foi encontrado.  Procure o administrador do site para habilitar o suporte necessário.',
);