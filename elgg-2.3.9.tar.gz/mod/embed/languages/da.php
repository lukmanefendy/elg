<?php
return array(
	'embed:embed' => 'Embed',
	'embed:media' => 'Embed indhold',
	'embed:instructions' => 'Klik på en fil for at embedde den i dit indhold.',
	'embed:upload' => 'Upload medie',
	'embed:upload_type' => 'Upload type: ',

	// messages
	'embed:no_upload_content' => 'Intet uploaded indhold!',
	'embed:no_section_content' => 'Ingen emner fundet.',

	'embed:no_sections' => 'No supported embed plugins found. Ask the site administrator to enabled a plugin with embed support.',
);