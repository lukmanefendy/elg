<?php
return array(
	'embed:embed' => 'Încorporare',
	'embed:media' => 'Încorporează conținut',
	'embed:instructions' => 'Apasă pe orice fișier pentru a-l încorpora în conținutul tău.',
	'embed:upload' => 'Încarcă media',
	'embed:upload_type' => 'Tipul încărcării: ',

	// messages
	'embed:no_upload_content' => 'Fără conținut încărcat!',
	'embed:no_section_content' => 'Nici un element găsit.',

	'embed:no_sections' => 'Nici un modul de încorporare găsit. Poți ruga administratorul acestui site să adauge un astfel de modul de încorporare.',
);