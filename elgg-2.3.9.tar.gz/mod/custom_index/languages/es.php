<?php
return array(	
	'custom:bookmarks' => "Los últimos marcadores",
	'custom:groups' => "&uacute;ltimos grupos",
	'custom:files' => "&uacute;ltimos archivos",
	'custom:blogs' => "&uacute;ltimos blogs",
	'custom:members' => "Nuevos miembros",
);
