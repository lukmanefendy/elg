<?php
return array(	
	'custom:bookmarks' => "Marcadores mais recentes",
	'custom:groups' => "Grupos mais recentes",
	'custom:files' => "Arquivos mais recentes",
	'custom:blogs' => "Postagens mais recentes",
	'custom:members' => " Membros mais recentes",
);
