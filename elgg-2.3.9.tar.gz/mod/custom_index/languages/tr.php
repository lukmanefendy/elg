<?php
return array(	
	'custom:bookmarks' => "En yeni yer imleri",
	'custom:groups' => "En yeni gruplar",
	'custom:files' => "En yeni dosyalar",
	'custom:blogs' => "En yeni blog gönderileri",
	'custom:members' => "Yeni üyeler",
);
