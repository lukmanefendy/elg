<?php
return array(	
	'custom:bookmarks' => "Azken laster-markak",
	'custom:groups' => "Azken taldeak",
	'custom:files' => "Azken fitxategiak",
	'custom:blogs' => "Blogeko azken bidalketak",
	'custom:members' => "Kide berrienak",
);
