<?php
/**
 * Discussion topic replies in the river
 *
 * @uses ElggObject $vars['topic'] Object with subtype "discussion"
 */

echo elgg_view('resources/elements/discussion_replies', $vars);