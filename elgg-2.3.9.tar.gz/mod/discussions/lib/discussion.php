<?php

elgg_deprecated_notice("The library 'elgg:discussion' is unneeded and will be removed.", "2.0");
