<?php

echo elgg_view_module('theme-sandbox-demo', 'Modules (.elgg-module)', elgg_view('theme_sandbox/modules/modules'));

echo elgg_view_module('theme-sandbox-demo', 'Widgets (.elgg-module-widget)', elgg_view('theme_sandbox/modules/widgets'));

