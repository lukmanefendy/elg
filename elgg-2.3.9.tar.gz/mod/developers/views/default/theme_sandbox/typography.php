<?php
/**
 * General CSS
 */

echo elgg_view_module('theme-sandbox-demo', "Headings", elgg_view('theme_sandbox/typography/headings'));

echo elgg_view_module('theme-sandbox-demo', "Fonts", elgg_view('theme_sandbox/typography/fonts'));

echo elgg_view_module('theme-sandbox-demo', "Paragraph", elgg_view('theme_sandbox/typography/paragraph'));

echo elgg_view_module('theme-sandbox-demo', "Misc", elgg_view('theme_sandbox/typography/misc'));