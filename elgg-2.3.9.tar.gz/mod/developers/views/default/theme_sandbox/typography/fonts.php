<ul>
	<li>Lorem ipsum dolor sit amet (body)</li>
	<li><span class="elgg-text-help" style="display: inline;">Lorem ipsum dolor sit amet</span> (.elgg-text-help)</li>
	<li><span class="elgg-quiet">Lorem ipsum dolor sit amet</span> (.elgg-quiet)</li>
	<li><span class="elgg-loud">Lorem ipsum dolor sit amet</span> (.elgg-loud)</li>
	<li><span class="elgg-monospace">Lorem ipsum dolor sit amet</span> (.elgg-monospace)</li>
</ul>