<?php
return array(
	'ckeditor:html' => "Editar HTML",
	'ckeditor:visual' => "Editor Visual",
	'ckeditor:blockimagepaste' => "No se permite pegar imágenes directamente.",
);
