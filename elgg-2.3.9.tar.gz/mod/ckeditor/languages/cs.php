<?php
return array(
	'ckeditor:html' => "Upravit HTML",
	'ckeditor:visual' => "Upravit vizuálně",
	'ckeditor:blockimagepaste' => "Není možné přímo vložit obrázek.",
);
