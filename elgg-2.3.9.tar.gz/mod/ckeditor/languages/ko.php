<?php
return array(
	'ckeditor:html' => "HTML 수정",
	'ckeditor:visual' => "위지윅 편집기",
);
