<?php
return array(
	'ckeditor:html' => "HTML edizioa",
	'ckeditor:visual' => "Edizio bisuala",
	'ckeditor:blockimagepaste' => "Irudia zuzenean itsastea ez dago baimenduta.",
);
