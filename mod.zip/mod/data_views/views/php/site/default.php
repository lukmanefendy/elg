<?php
/**
 * PHP site view
 *
 * @package Elgg
 * @subpackage Core
 */

elgg_view('export/entity', $vars);