<?php
/**
 * ICal layout shell
 */

echo $vars['content'];
