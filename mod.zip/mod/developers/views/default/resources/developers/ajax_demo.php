<?php

echo elgg_view_page("Ajax demo", elgg_view_layout('content', [
	'title' => 'path demo',
	'content' => '',
]));
