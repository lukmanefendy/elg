<?php

echo elgg_view_layout('one_sidebar', array(
	'sidebar' => 'Sidebar',
	'title' => 'The Title',
	'content' => '<p>The one_sidebar layout has a main content area and a single
		sidebar that can be position to the left or right by using CSS.</p>',
));
