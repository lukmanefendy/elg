<?php


echo elgg_view_layout('one_column', array(
	'title' => 'The Title',
	'content' => '<p>The one_column layout has only a main content area.</p>',
));
