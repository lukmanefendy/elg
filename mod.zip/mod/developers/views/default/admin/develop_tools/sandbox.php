<?php
/**
 * CSS Sandbox
 */

$url = elgg_get_site_url() . 'theme_sandbox/intro';
?>
<iframe id="developers-iframe" src="<?php echo $url; ?>"></iframe>