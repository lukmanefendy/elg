<?php

/**
 * @access private
 */
class ThemeSandboxObject extends ElggObject {
	public function getTimeCreated() {
		return time();
	}
}
