<?php
return array(	
	'custom:bookmarks' => "Derniers signets ajoutés",
	'custom:groups' => "Derniers groupes créés",
	'custom:files' => "Derniers fichiers publiés",
	'custom:blogs' => "Derniers articles de blog publiés",
	'custom:members' => "Nouveaux membres",
);
