<?php
return array(	
	'custom:bookmarks' => "Darreres dreceres",
	'custom:groups' => "Darrers grups",
	'custom:files' => "Darrers fitxers",
	'custom:blogs' => "Darreres entrades",
	'custom:members' => "Darrers membres",
);
