<?php
return array(	
	'custom:bookmarks' => "新進書籤",
	'custom:groups' => "新進群組",
	'custom:files' => "新進檔案",
	'custom:blogs' => "新進部落格貼文",
	'custom:members' => "新進成員",
);
