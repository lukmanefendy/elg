<?php
return array(	
	'custom:bookmarks' => "Nejnovější záložky",
	'custom:groups' => "Nejnovější skupiny",
	'custom:files' => "Nejnovější soubory",
	'custom:blogs' => "Nejnovější blogy",
	'custom:members' => "Nejnovější členové",
);
