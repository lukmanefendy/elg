<?php
return array(	
	'custom:bookmarks' => "Laatste favorieten",
	'custom:groups' => "Laatste groepen",
	'custom:files' => "Laatste bestanden",
	'custom:blogs' => "Laatste blogberichten",
	'custom:members' => "Nieuwste leden",
);
