<?php
return array(	
	'custom:bookmarks' => "Πρόσφατοι σύνδεσμοι",
	'custom:groups' => "Πρόσφατες ομάδες",
	'custom:files' => "Πρόσφατα αρχεία",
	'custom:blogs' => "Πρόσφατες αναρτήσεις στο ιστολόγιο",
	'custom:members' => "Νεώτερα μέλη",
);
