<?php
return array(	
	'custom:bookmarks' => "Na comharran-lìn as ùire",
	'custom:groups' => "Na buidhnean as ùire",
	'custom:files' => "Na faidhlichean as ùire",
	'custom:blogs' => "Na postaichean bloga as ùire",
	'custom:members' => "Na buill as ùire",
);
