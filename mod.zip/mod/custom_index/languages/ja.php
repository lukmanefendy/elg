<?php
return array(	
	'custom:bookmarks' => "新着ブックマーク",
	'custom:groups' => "新着グループ",
	'custom:files' => "新着ファイル",
	'custom:blogs' => "新着ブログ記事",
	'custom:members' => "最近の参加メンバー",
);
