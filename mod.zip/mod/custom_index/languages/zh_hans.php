<?php
return array(	
	'custom:bookmarks' => "最新的书签",
	'custom:groups' => "最新的群组",
	'custom:files' => "最新的文件",
	'custom:blogs' => "最新的博文",
	'custom:members' => "最新的会员",
);
