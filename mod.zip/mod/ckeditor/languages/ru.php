<?php
return array(
	'ckeditor:html' => "Редактировать HTML",
	'ckeditor:visual' => "Визуальный редактор",
	'ckeditor:blockimagepaste' => "Редактор не поддерживает вставку изображений напрямую",
);
