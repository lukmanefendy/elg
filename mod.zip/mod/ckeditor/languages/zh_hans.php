<?php
return array(
	'ckeditor:html' => "编辑HTML",
	'ckeditor:visual' => "可视化编辑器",
	'ckeditor:blockimagepaste' => "不允许直接粘贴图片",
);
