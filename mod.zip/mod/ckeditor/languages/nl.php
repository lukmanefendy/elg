<?php
return array(
	'ckeditor:html' => "Bewerk HTML",
	'ckeditor:visual' => "Visuele editor",
	'ckeditor:blockimagepaste' => "Direct plakken van afbeeldingen is niet toegestaan.",
);
