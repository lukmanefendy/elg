<?php
return array(
	'ckeditor:html' => "Deasaich HTML",
	'ckeditor:visual' => "Deasaiche lèirsinneach",
	'ckeditor:blockimagepaste' => "Chan fhaodar dealbh a chur ann gu dìreach.",
);
