<?php
return array(
	'ckeditor:html' => "Edytuj HTML",
	'ckeditor:visual' => "Edytor graficzny",
	'ckeditor:blockimagepaste' => "Bezpośrednie wstawianie obrazów jest zablokowane.",
);
