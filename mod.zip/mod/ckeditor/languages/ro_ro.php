<?php
return array(
	'ckeditor:html' => "Editează HTML",
	'ckeditor:visual' => "Editor vizual",
	'ckeditor:blockimagepaste' => "Lipirea directă de imagine nu este permisă.",
);
