<?php
return array(
	'ckeditor:html' => "Muokkaa HTML:ää",
	'ckeditor:visual' => "Näytä editori",
	'ckeditor:blockimagepaste' => "Kuvien suora liittäminen on estetty.",
);
