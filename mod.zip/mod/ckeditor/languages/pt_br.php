<?php
return array(
	'ckeditor:html' => "Editar HTML",
	'ckeditor:visual' => "Editor visual",
	'ckeditor:blockimagepaste' => "Não é permitida colagem de fotos.",
);
