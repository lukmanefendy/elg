<?php
return array(
	'ckeditor:html' => "HTMLを編集",
	'ckeditor:visual' => "ビジュアルエディタ",
	'ckeditor:blockimagepaste' => "画像の直接ペーストはできません。",
);
