<?php
return array(
	'ckeditor:html' => "Edita HTML",
	'ckeditor:visual' => "Editor visual",
	'ckeditor:blockimagepaste' => "No es permet enganxar una imatge directament",
);
