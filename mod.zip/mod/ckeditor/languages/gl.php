<?php
return array(
	'ckeditor:html' => "Editor de HTML",
	'ckeditor:visual' => "Editor visual",
	'ckeditor:blockimagepaste' => "Non se permite pergar imaxes directamente.",
);
