<?php
return array(
	'ckeditor:html' => "Modifica HTML",
	'ckeditor:visual' => "Interfaccia di modifica",
	'ckeditor:blockimagepaste' => "Non è possibile incollare le immagini.",
);
