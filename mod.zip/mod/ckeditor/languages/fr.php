<?php
return array(
	'ckeditor:html' => "Éditer le HTML",
	'ckeditor:visual' => "Éditeur visuel",
	'ckeditor:blockimagepaste' => "Il n'est pas permis de coller directement une image.",
);
