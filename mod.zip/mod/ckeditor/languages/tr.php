<?php
return array(
	'ckeditor:html' => "HTML düzenle",
	'ckeditor:visual' => "Görsel editör",
	'ckeditor:blockimagepaste' => "Doğrudan görsel yapıştırmaya izin verilmez.",
);
