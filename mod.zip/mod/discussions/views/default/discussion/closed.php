<?php
/**
 * Topic is closed
 */
echo "<div class=\"elgg-box elgg-state-notice\">";
	echo "<h3>" . elgg_echo("discussion:topic:closed:title") . "</h3>";
	echo "<p>" . elgg_echo("discussion:topic:closed:desc") . "</p>";
echo "</div>";