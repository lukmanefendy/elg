<?php
return array(
	'embed:embed' => 'Includi',
	'embed:media' => 'Includi contenuti',
	'embed:instructions' => 'Clicca su un file per includerlo nei tuoi contenuti.',
	'embed:upload' => 'Carica file',
	'embed:upload_type' => 'Tipo di caricamento:',

	// messages
	'embed:no_upload_content' => 'Nessun contenuto da caricare!',
	'embed:no_section_content' => 'Nessun elemento trovato.',

	'embed:no_sections' => 'Non abbiamo trovato alcun plugin supportato per l\'incorporamento. Chiedi all\'amministratore del sito di abilitare un plugin che supporti l\'incorporamento.',
);