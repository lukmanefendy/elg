<?php
return array(
	'embed:embed' => 'Toevoegen',
	'embed:media' => 'Bijlage toevoegen',
	'embed:instructions' => 'Klik op een bestand om het aan je content toe te voegen.',
	'embed:upload' => 'Upload media',
	'embed:upload_type' => 'Upload type:',

	// messages
	'embed:no_upload_content' => 'Er is niets om te uploaden!',
	'embed:no_section_content' => 'Geen items gevonden',

	'embed:no_sections' => 'Er is geen plugin geactiveerd die het mogelijk maakt om bijlagen toe te voegen. Je kunt aan de sitebeheerder vragen om dit wel mogelijk te maken.',
);