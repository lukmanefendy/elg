<?php
return array(
	'embed:embed' => 'Osadź',
	'embed:media' => 'Osadź treść',
	'embed:instructions' => 'Kliknij na dowolnym pliku aby osadzić go w treści.',
	'embed:upload' => 'Wgraj media',
	'embed:upload_type' => 'Rodzaj wgrywanej treści:',

	// messages
	'embed:no_upload_content' => 'Brak wgranej treści!',
	'embed:no_section_content' => 'Nie znaleziono elementów.',

	'embed:no_sections' => 'Nie znaleziono wspieranych wtyczek osadzających. Zapytaj administratora o wtyczki wspierające osadzanie.',
);