<?php
return array(
	'embed:embed' => 'Incrustado',
	'embed:media' => 'Contenido incrustado',
	'embed:instructions' => 'Click en cualquier archivo paraincrustar en el contenido.',
	'embed:upload' => 'Subir medios',
	'embed:upload_type' => 'Tipo de carga: ',

	// messages
	'embed:no_upload_content' => 'No hay contenidos subidos',
	'embed:no_section_content' => 'No hay elementos encontrados.',

	'embed:no_sections' => 'No se han encontrado plugins de contenido incrustado. Pregunte al administrador del sitio para habilitar un plugin con soporte de contenido incrustado.',
);