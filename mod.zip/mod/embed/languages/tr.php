<?php
return array(
	'embed:embed' => 'Göm',
	'embed:media' => 'İçeriği göm',
	'embed:instructions' => 'İçeriğinize eklemek için herhangi bir dosyaya tıklayın.',
	'embed:upload' => 'Medya yükle',
	'embed:upload_type' => 'Yükleme türü:',

	// messages
	'embed:no_upload_content' => 'Yükleme içeriği yok!',
	'embed:no_section_content' => 'Öğe bulunamadı.',

	'embed:no_sections' => 'Desteklenen gömme eklentisi bulunamadı. Gömme desteği sunan bir eklenti etkinleştirmesi için site yöneticisiyle bağlantı kurun.',
);