<?php
return array(
	'embed:embed' => 'Leabaich',
	'embed:media' => 'Leabaich susbaint',
	'embed:instructions' => 'Briog air faidhle sam bith gus a leabachadh san t-susbaint agad.',
	'embed:upload' => 'Luchdaich suas meadhan',
	'embed:upload_type' => 'Seòrsa an luchdaidh suas:',

	// messages
	'embed:no_upload_content' => 'Chan eil susbaint luchdaidh suas ann!',
	'embed:no_section_content' => 'Cha deach nì a lorg.',

	'embed:no_sections' => 'Cha deach plugan leabachaidh a lorg ris an cuir sinn taic. Iarr aid rianaire na làraich gun cuir e plugan an comas a chuireas taic ri leabachadh.',
);