<?php
return array(
	'embed:embed' => '끼워넣기',
	'embed:media' => '내용을 끼워넣습니다',
	'embed:instructions' => '당신의 글에 끼워넣을 파일을 누르세요',
	'embed:upload' => '미디어 올리기',
	'embed:upload_type' => '올리기 형태',

	// messages
	'embed:no_upload_content' => '올릴 내용이 없습니다!',
	'embed:no_section_content' => '항목이 없습니다.',

	'embed:no_sections' => '지원되는 끼워넣기 플러긴을 찾을 수 없었습니다. 관리자에게 해당 기능을 활성화해달라고 요구하세요.',
);