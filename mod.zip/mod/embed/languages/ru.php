<?php
return array(
	'embed:embed' => 'Медиа',
	'embed:media' => 'Вставить',
	'embed:instructions' => 'Для вставки нажмите на файл',
	'embed:upload' => 'Загрузить:',
	'embed:upload_type' => 'Тип загрузки: ',

	// messages
	'embed:no_upload_content' => 'Не загружен контент!',
	'embed:no_section_content' => 'Не найдено.',

	'embed:no_sections' => 'Нет возможности загрузить файлы. Ваш администратор должен активировать файловый плагин.',
);