<?php
return array(
	'embed:embed' => '嵌入',
	'embed:media' => '嵌入内容',
	'embed:instructions' => '点击任意文件以嵌入到你的内容中',
	'embed:upload' => '上传媒体文件',
	'embed:upload_type' => '上传类型：',

	// messages
	'embed:no_upload_content' => '无上传内容',
	'embed:no_section_content' => '无项目',

	'embed:no_sections' => '无支持的嵌入插件。请联系管理员启用支持嵌入的插件。',
);