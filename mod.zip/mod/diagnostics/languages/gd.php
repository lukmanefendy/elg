<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Diagnosachd an t-siostaim',
	'diagnostics' => 'Diagnosachd an t-siostaim',
	'diagnostics:report' => 'Aithisg na diagnosachd',
	'diagnostics:description' => 'Faodaidh aithisg na diagnosachd seo a bhith feumail gus duilgheadasan le Elgg a sgrùdadh. \'S dòcha gun iarr luchd-leasachaidh Elgg ort gun cuir thu ri aithris aig buga e.',
	'diagnostics:header' => '========================================================================
Aithisg diagnosachd Elgg
Air a ghintinn %s le %s
========================================================================

',
	'diagnostics:report:basic' => '
Sgaoileadh Elgg %s, tionndadh %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
Fiosrachadh PHP:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Fiosrachadh nam plugan a chaidh a stàladh:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Faidhlichean a chaidh a stàladh \'s an suimeannan-dearbhaidh:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Caochladairean uile-choitcheann:

%s
------------------------------------------------------------------------',
);