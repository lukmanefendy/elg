<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Ekstra sider",
	'admin:appearance:expages' => "Ekstra sider",
	'expages:about' => "Om",
	'expages:terms' => "Betingelser",
	'expages:privacy' => "Beskyttelse af personlige oplysninger",
	'expages:contact' => "Kontakt",

	'expages:notset' => "Denne side er ikke sat op endnu.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Din side blev opdateret.",
	'expages:error' => "Kunne ikke gemme denne side.",
);