<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Páginas externas",
	'admin:appearance:expages' => "Páginas externas",
	'expages:about' => "Sobre",
	'expages:terms' => "Termos",
	'expages:privacy' => "Privacidade",
	'expages:contact' => "Contatos",

	'expages:notset' => "Esta página ainda não foi configurada.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Sua página foi enviada com sucesso.",
	'expages:error' => "Ocorreu um erro, por favor tente novamente e se o problema persistir contate o administrador",
);