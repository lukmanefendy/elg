<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "누리집 페이지",
	'admin:appearance:expages' => "누리집 페이지",
	'expages:about' => "정보",
	'expages:terms' => "용어",
	'expages:privacy' => "개인정보보호",
	'expages:contact' => "연락",

	'expages:notset' => "이 페이지는 아직 설정되지 않았습니다.",

	/**
	 * Status messages
	 */
	'expages:posted' => "페이지가 성공적으로 갱신되었습니다.",
	'expages:error' => "이 페이지를 저장할 수 없슴.",
);