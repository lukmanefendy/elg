<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Informační stránky",
	'admin:appearance:expages' => "Informační stránky",
	'expages:edit:viewpage' => "Zobrazit na stránce",
	'expages:about' => "O těchto stránkách",
	'expages:terms' => "Podmínky",
	'expages:privacy' => "Soukromí",
	'expages:contact' => "Kontakt",

	'expages:notset' => "Tato stránka zatím nebyla nastavena.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Stránka byla úspěšně aktualizována.",
	'expages:error' => "Tuto stránku nemohu uložit.",
);