<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Стране сајта",
	'admin:appearance:expages' => "Стране Сајта",
	'expages:edit:viewpage' => "Погледај страницу на сајту",
	'expages:about' => "О сајту",
	'expages:terms' => "Услови коришћења",
	'expages:privacy' => "Приватност",
	'expages:contact' => "Контакт",

	'expages:notset' => "Ова страна није уређена.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Страна је успешно сачувана.",
	'expages:error' => "Страна није сачувана.",
);