<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Σελίδες ιστότοπου",
	'admin:appearance:expages' => "Σελίδες Ιστότοπου",
	'expages:edit:viewpage' => "Προβολή σελίδας",
	'expages:about' => "Περί",
	'expages:terms' => "Όροι Χρήσης",
	'expages:privacy' => "Ιδιωτικότητα",
	'expages:contact' => "Επικοινωνία",

	'expages:notset' => "Αυτή η σελίδα δεν έχει καθοριστεί ακόμα.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Η σελίδα σας ενημερώθηκε.",
	'expages:error' => "Αδύνατη η αποθήκευση της σελίδας.",
);