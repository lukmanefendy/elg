<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Pagini de site",
	'admin:appearance:expages' => "Paginile siteului",
	'expages:edit:viewpage' => "Vizualizează pagina pe site",
	'expages:about' => "Despre",
	'expages:terms' => "Termeni",
	'expages:privacy' => "Intimitate",
	'expages:contact' => "Contact",

	'expages:notset' => "Această pagină nu a fost configurată încă.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Pagina ta a fost actualizată cu succes.",
	'expages:error' => "Nu s-a putut salva această pagină.",
);