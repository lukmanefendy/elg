<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Pàgines externes",
	'admin:appearance:expages' => "Pàgines",
	'expages:about' => "Sobre",
	'expages:terms' => "Termes",
	'expages:privacy' => "Privadesa",
	'expages:contact' => "Contacte",

	'expages:notset' => "No s'ha iniciat la pàgina.",

	/**
	 * Status messages
	 */
	'expages:posted' => "S'ha enviat correctament la pàgina",
	'expages:error' => "Ui, torna-ho a provar o posa't en contacte l'administrador/a de la xarxa.",
);