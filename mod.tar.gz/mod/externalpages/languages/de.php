<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Externe Seiten",
	'admin:appearance:expages' => "Externe Seiten",
	'expages:edit:viewpage' => "Diese externe Seite anzeigen",
	'expages:about' => "Impressum",
	'expages:terms' => "AGBs",
	'expages:privacy' => "Datenschutz",
	'expages:contact' => "Kontakt",

	'expages:notset' => "Diese Seite wurde noch nicht eingerichtet.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Dein Seiten-Eintrag wurde gespeichert.",
	'expages:error' => "Beim Speichern der Seite ist ein Fehler aufgetreten.",
);