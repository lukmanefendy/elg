<?php
/**
 * External pages menu
 *
 * @uses $vars['type']
 */

$vars['class'] = 'elgg-tabs';
echo elgg_view_menu('expages', $vars);
