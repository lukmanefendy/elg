data_views
----------
This plugin adds viewtypes that were formerly part of the Elgg core (1.0-1.8).

View types
----------
php: used for web services to return results as serialized PHP objects
xml: used by web services to return results in XML format
ical: provide an iCalendar file for objects that have dates
