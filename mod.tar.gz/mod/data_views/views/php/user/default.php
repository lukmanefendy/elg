<?php
/**
 * PHP user view
 *
 * @package Elgg
 * @subpackage Core
 */

echo elgg_view('export/entity', $vars);