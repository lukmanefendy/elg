<?php
/**
 * PHP output pageshell
 *
 * @package Elgg
 * @subpackage Core
 */

echo $vars['body'];