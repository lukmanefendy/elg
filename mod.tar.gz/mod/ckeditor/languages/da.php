<?php
return array(
	'ckeditor:html' => "Ændre HTML",
	'ckeditor:visual' => "Visuel redigering",
);
