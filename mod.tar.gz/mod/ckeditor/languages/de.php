<?php
return array(
	'ckeditor:html' => "Editor deaktivieren",
	'ckeditor:visual' => "Editor aktivieren",
	'ckeditor:blockimagepaste' => "Direktes Einfügen von Bildern ist nicht erlaubt.",
);
