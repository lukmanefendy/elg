<?php
return array(
	'ckeditor:html' => "ویرایش htm",
	'ckeditor:visual' => "ویرایشگر بصری",
);
