<?php
return array(
	'ckeditor:html' => "Edit HTML",
	'ckeditor:visual' => "Visual editor",
	'ckeditor:blockimagepaste' => "Direct image paste is not allowed.",
);
