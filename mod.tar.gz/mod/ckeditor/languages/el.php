<?php
return array(
	'ckeditor:html' => "Επεξεργασία κώδικα HML",
	'ckeditor:visual' => "Οπτική επεξεργασία",
	'ckeditor:blockimagepaste' => "Δεν επιτρέπεται η απευθείας επικόλληση εικόνων",
);
