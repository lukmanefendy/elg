<?php
return array(
	'embed:embed' => 'Incrustar',
	'embed:media' => 'Incrustar o contido',
	'embed:instructions' => 'Prema calquera ficheiro para incrustalo no seu contido.',
	'embed:upload' => 'Enviar un ficheiro',
	'embed:upload_type' => 'Tipo de ficheiro:',

	// messages
	'embed:no_upload_content' => 'Non seleccionou nada que enviar!',
	'embed:no_section_content' => 'Non se atopou ningún elemento',

	'embed:no_sections' => 'Non se atopou ningún complemento de incrustación compatíbel. Solicítelle ao administrador que active un complemento compatíbel con incrustacións.',
);