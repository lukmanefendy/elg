<?php
return array(
	'embed:embed' => 'Kapsulaketa',
	'embed:media' => 'Kapsulatutako edukia',
	'embed:instructions' => 'Klikatu edozein fitxategitan zure edukian kapsulatzeko.',
	'embed:upload' => 'Igo euskarria',
	'embed:upload_type' => 'Igotako mota:',

	// messages
	'embed:no_upload_content' => 'Igotako edukirik ez!',
	'embed:no_section_content' => 'Ez da elementurik aurkitu.',

	'embed:no_sections' => 'Ez da aurkitu kapsulaketarekin bateragarria den pluginik. Administratzaileari galdetu kapsulaketarekin bateragarria den plugin bat gaitzeko.',
);