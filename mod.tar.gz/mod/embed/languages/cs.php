<?php
return array(
	'embed:embed' => 'Vložit',
	'embed:media' => 'Vložený obsah',
	'embed:instructions' => 'Pro přidání do vašeho obsahu klikněte na soubor.',
	'embed:upload' => 'Nahrát média',
	'embed:upload_type' => 'Typ nahrání:',

	// messages
	'embed:no_upload_content' => 'Žádný nahraný obsah!',
	'embed:no_section_content' => 'Nenalezeny žádné položky.',

	'embed:no_sections' => 'Nebyl nalezen doplněk s podporou vkládání. Požádejte správce aby takový doplněk povolil.',
);