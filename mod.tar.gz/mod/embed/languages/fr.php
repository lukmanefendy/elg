<?php
return array(
	'embed:embed' => 'Intégrer un contenu',
	'embed:media' => 'Intégrer un média',
	'embed:instructions' => 'Cliquez sur l\'élément de votre choix pour l\'intégrer dans le contenu.',
	'embed:upload' => 'Envoyer un fichier média',
	'embed:upload_type' => 'Type d\'envoi : ',

	// messages
	'embed:no_upload_content' => 'Aucun contenu chargé !',
	'embed:no_section_content' => 'Aucun élément trouvé.',

	'embed:no_sections' => 'Aucun plugin gérant l\'intégration de fichier média n\'a été trouvé. Demandez à l\'administrateur du site d\'activer un plugin qui gère l\'intégration de fichier média.',
);