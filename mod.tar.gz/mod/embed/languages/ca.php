<?php
return array(
	'embed:embed' => 'Incrustat',
	'embed:media' => 'Contingut incrustat',
	'embed:instructions' => 'Prem a qualsevol fitxer per incrustar-lo al teu contingut.',
	'embed:upload' => 'Puja multimèdia',
	'embed:upload_type' => 'Tipus:',

	// messages
	'embed:no_upload_content' => 'No hi ha contingut!',
	'embed:no_section_content' => 'No s\'ha trobat res.',

	'embed:no_sections' => 'No s\'han trobat extensions suportades. Consulta-ho amb l\'administrador del lloc per a que habiliti una extensió amb suport per incrustar recursos.',
);