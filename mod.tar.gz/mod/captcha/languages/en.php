<?php
/**
 * Elgg language pack for Captcha plugin.
 *
 */

return [
	'captcha:entercaptcha' => 'Enter the text from the image',
	'captcha:captchafail' => 'Sorry, the text that you entered didn\'t match the text in the image.',
];