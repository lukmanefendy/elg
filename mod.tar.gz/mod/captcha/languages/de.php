<?php
/**
 * Elgg German language pack for Captcha plugin.
 *
 */

return [
	'captcha:entercaptcha' => 'Bitte den im Bild angezeigten Text eingeben',
	'captcha:captchafail' => 'Entschuldigung, der eingegebene Text stimmt nicht mit dem im Bild angezeigten Text überein.',
];