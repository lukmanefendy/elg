<?php
return array(	
	'custom:bookmarks' => "Viimeisimmät kirjanmerkit",
	'custom:groups' => "Viimeisimmät ryhmät",
	'custom:files' => "Viimeisimmät tiedostot",
	'custom:blogs' => "Viimeisimmät blogit",
	'custom:members' => "Uusimmat jäsenet",
);
