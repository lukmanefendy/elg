<?php
return array(	
	'custom:bookmarks' => "최신 책갈피",
	'custom:groups' => "최신 모둠",
	'custom:files' => "최신 파일",
	'custom:blogs' => "최신 블로그글",
	'custom:members' => "최신 회원",
);
