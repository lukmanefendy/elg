<?php
return array(	
	'custom:bookmarks' => "Últimos marcadores",
	'custom:groups' => "Últimos grupos",
	'custom:files' => "Últimos ficheiros",
	'custom:blogs' => "Últimos artigos",
	'custom:members' => "Últimos membros",
);
