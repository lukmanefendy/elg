<?php
return array(	
	'custom:bookmarks' => "Nuovi segnalibri",
	'custom:groups' => "Nuovi gruppi",
	'custom:files' => "Nuovi file",
	'custom:blogs' => "Nuovi articoli nel blog",
	'custom:members' => "Nuovi membri",
);
