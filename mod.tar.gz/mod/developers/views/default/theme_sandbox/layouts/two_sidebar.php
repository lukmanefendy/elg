<?php


echo elgg_view_layout('two_sidebar', array(
	'sidebar' => 'Primary Sidebar',
	'sidebar_alt' => 'Alternate Sidebar',
	'title' => 'The Title',
	'content' => '<p>The two_sidebar layout has a main content area and 2 sidebars.</p>',
));
