<?php
/**
 * Icons CSS
 */

echo elgg_view_module('theme-sandbox-demo', 'Icons (.elgg-icon)', elgg_view('theme_sandbox/icons/sprites'));

echo elgg_view_module('theme-sandbox-demo', 'Ajax Loader (.elgg-ajax-loader)', elgg_view('theme_sandbox/icons/loader'));

echo elgg_view_module('theme-sandbox-demo', 'Avatars (.elgg-avatar)', elgg_view('theme_sandbox/icons/avatars'));
