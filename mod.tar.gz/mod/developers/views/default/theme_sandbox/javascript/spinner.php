<p class="theme-sandbox-content-spinner">
	<a data-method="start" class="mls" href="#">spinner.start();</a>
	<a data-method="start" data-spinner-text="Feeding the hamster" class="mls" href="#">spinner.start('Feeding the hamster');</a>
	<a data-method="stop" class="mls" href="#">spinner.stop();</a>
</p>
