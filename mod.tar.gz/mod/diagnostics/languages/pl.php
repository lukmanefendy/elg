<?php
return array(
	'admin:administer_utilities:diagnostics' => 'Diagnostyka systemu',
	'diagnostics' => 'Diagnostyka systemu',
	'diagnostics:report' => 'Raport diagnostyczny',
	'diagnostics:description' => 'Niniejszy raport diagnostyczny może być przydatny w rozwiązywaniu problemów z Elgg. Deweloperzy Elgg\'a mogą oczekiwać, że go załączysz do zgłoszenia błędu.',
	'diagnostics:header' => '========================================================================
Raport diagnostyczny Elgg
Wygenerowany %s przez %s
========================================================================

',
	'diagnostics:report:basic' => '
Wydanie Elgg %s, wersja %s

------------------------------------------------------------------------',
	'diagnostics:report:php' => '
PHP info:
%s
------------------------------------------------------------------------',
	'diagnostics:report:plugins' => '
Zainstalowane pluginy i szczegóły:

%s
------------------------------------------------------------------------',
	'diagnostics:report:md5' => '
Zainstalowane pliki i sumy kontrolne:

%s
------------------------------------------------------------------------',
	'diagnostics:report:globals' => '
Zmienne globalne:

%s
------------------------------------------------------------------------',
);